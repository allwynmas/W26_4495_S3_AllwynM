CREATE TABLE IF NOT EXISTS challenge_progress (
                                                  id                    INT AUTO_INCREMENT PRIMARY KEY,
                                                  username              VARCHAR(100) NOT NULL UNIQUE,

    -- SQLi levels
    sqli_level1_completed BOOLEAN DEFAULT FALSE,
    sqli_level2_completed BOOLEAN DEFAULT FALSE,
    sqli_level3_completed BOOLEAN DEFAULT FALSE,

    -- XSS levels
    xss_level1_completed  BOOLEAN DEFAULT FALSE,
    xss_level2_completed  BOOLEAN DEFAULT FALSE,

    -- CSRF levels
    csrf_level1_completed BOOLEAN DEFAULT FALSE,
    csrf_level2_completed BOOLEAN DEFAULT FALSE,

    -- IDOR levels
    idor_level1_completed BOOLEAN DEFAULT FALSE,
    idor_level2_completed BOOLEAN DEFAULT FALSE,

    -- Gamification
    xp                    INT DEFAULT 0,
    sqlie_badge_earned    BOOLEAN DEFAULT FALSE,
    xss_badge_earned      BOOLEAN DEFAULT FALSE,
    csrf_badge_earned     BOOLEAN DEFAULT FALSE,
    idor_badge_earned     BOOLEAN DEFAULT FALSE


    -- Broken Authentication levels
    broken_auth_level1_completed BOOLEAN DEFAULT FALSE,
    broken_auth_level2_completed BOOLEAN DEFAULT FALSE,
    broken_auth_level3_completed BOOLEAN DEFAULT FALSE,

-- Badge
    broken_auth_badge_earned BOOLEAN DEFAULT FALSE

    );


