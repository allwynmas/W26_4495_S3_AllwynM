package com.akmlab.ibd.model;

import jakarta.persistence.*;

@Entity
@Table(name = "challenge_progress")
public class ChallengeProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Links this progress record to a specific logged-in user
    @Column(unique = true, nullable = false)
    private String username;

    // SQLi challenge completion
    private boolean sqliLevel1Completed = false;
    private boolean sqliLevel2Completed = false;
    private boolean sqliLevel3Completed = false;

    // XSS challenge completion
    private boolean xssLevel1Completed = false;
    private boolean xssLevel2Completed = false;

    // CSRF challenge completion
    private boolean csrfLevel1Completed = false;
    private boolean csrfLevel2Completed = false;

    // IDOR challenge completion
    private boolean idorLevel1Completed = false;
    private boolean idorLevel2Completed = false;

    // Broken Authentication challenge completion
    private boolean brokenAuthLevel1Completed = false;
    private boolean brokenAuthLevel2Completed = false;
    private boolean brokenAuthLevel3Completed = false;

    // File Upload challenge completion
    private boolean fileUploadLevel1Completed = false;
    private boolean fileUploadLevel2Completed = false;
    private boolean fileUploadLevel3Completed = false;

    // Gamification
    private int xp = 0;
    private boolean sqlieBadgeEarned = false;
    private boolean xssBadgeEarned = false;
    private boolean csrfBadgeEarned = false;
    private boolean idorBadgeEarned = false;
    private boolean brokenAuthBadgeEarned = false;
    private boolean fileUploadBadgeEarned = false;

    // ── Constructors ──────────────────────────────────────
    public ChallengeProgress() {}

    public ChallengeProgress(String username) {
        this.username = username;
    }

    // ── Getters & Setters ─────────────────────────────────
    public Long getId() { return id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    // SQLi
    public boolean isSqliLevel1Completed() { return sqliLevel1Completed; }
    public void setSqliLevel1Completed(boolean v) { this.sqliLevel1Completed = v; }

    public boolean isSqliLevel2Completed() { return sqliLevel2Completed; }
    public void setSqliLevel2Completed(boolean v) { this.sqliLevel2Completed = v; }

    public boolean isSqliLevel3Completed() { return sqliLevel3Completed; }
    public void setSqliLevel3Completed(boolean v) { this.sqliLevel3Completed = v; }

    // XSS
    public boolean isXssLevel1Completed() { return xssLevel1Completed; }
    public void setXssLevel1Completed(boolean v) { this.xssLevel1Completed = v; }

    public boolean isXssLevel2Completed() { return xssLevel2Completed; }
    public void setXssLevel2Completed(boolean v) { this.xssLevel2Completed = v; }

    // CSRF
    public boolean isCsrfLevel1Completed() { return csrfLevel1Completed; }
    public void setCsrfLevel1Completed(boolean v) { this.csrfLevel1Completed = v; }

    public boolean isCsrfLevel2Completed() { return csrfLevel2Completed; }
    public void setCsrfLevel2Completed(boolean v) { this.csrfLevel2Completed = v; }

    // IDOR
    public boolean isIdorLevel1Completed() { return idorLevel1Completed; }
    public void setIdorLevel1Completed(boolean v) { this.idorLevel1Completed = v; }

    public boolean isIdorLevel2Completed() { return idorLevel2Completed; }
    public void setIdorLevel2Completed(boolean v) { this.idorLevel2Completed = v; }

    // Broken Auth
    public boolean isBrokenAuthLevel1Completed() { return brokenAuthLevel1Completed; }
    public void setBrokenAuthLevel1Completed(boolean v) { this.brokenAuthLevel1Completed = v; }

    public boolean isBrokenAuthLevel2Completed() { return brokenAuthLevel2Completed; }
    public void setBrokenAuthLevel2Completed(boolean v) { this.brokenAuthLevel2Completed = v; }

    public boolean isBrokenAuthLevel3Completed() { return brokenAuthLevel3Completed; }
    public void setBrokenAuthLevel3Completed(boolean v) { this.brokenAuthLevel3Completed = v; }

    public boolean isBrokenAuthBadgeEarned() { return brokenAuthBadgeEarned; }
    public void setBrokenAuthBadgeEarned(boolean v) { this.brokenAuthBadgeEarned = v; }

    // File Upload
    public boolean isFileUploadLevel1Completed() { return fileUploadLevel1Completed; }
    public void setFileUploadLevel1Completed(boolean v) { this.fileUploadLevel1Completed = v; }

    public boolean isFileUploadLevel2Completed() { return fileUploadLevel2Completed; }
    public void setFileUploadLevel2Completed(boolean v) { this.fileUploadLevel2Completed = v; }

    public boolean isFileUploadLevel3Completed() { return fileUploadLevel3Completed; }
    public void setFileUploadLevel3Completed(boolean v) { this.fileUploadLevel3Completed = v; }

    public boolean isFileUploadBadgeEarned() { return fileUploadBadgeEarned; }
    public void setFileUploadBadgeEarned(boolean v) { this.fileUploadBadgeEarned = v; }

    // XP & Badges
    public int getXp() { return xp; }
    public void setXp(int xp) { this.xp = xp; }
    public void addXp(int amount) { this.xp += amount; }

    public boolean isSqlieBadgeEarned() { return sqlieBadgeEarned; }
    public void setSqlieBadgeEarned(boolean v) { this.sqlieBadgeEarned = v; }

    public boolean isXssBadgeEarned() { return xssBadgeEarned; }
    public void setXssBadgeEarned(boolean v) { this.xssBadgeEarned = v; }

    public boolean isCsrfBadgeEarned() { return csrfBadgeEarned; }
    public void setCsrfBadgeEarned(boolean v) { this.csrfBadgeEarned = v; }

    public boolean isIdorBadgeEarned() { return idorBadgeEarned; }
    public void setIdorBadgeEarned(boolean v) { this.idorBadgeEarned = v; }

    // ── Computed helpers ──────────────────────────────────
    public int getTotalChallengesCompleted() {
        int count = 0;
        if (sqliLevel1Completed) count++;
        if (sqliLevel2Completed) count++;
        if (sqliLevel3Completed) count++;
        if (xssLevel1Completed) count++;
        if (xssLevel2Completed) count++;
        if (csrfLevel1Completed) count++;
        if (csrfLevel2Completed) count++;
        if (idorLevel1Completed) count++;
        if (idorLevel2Completed) count++;
        if (brokenAuthLevel1Completed) count++;
        if (brokenAuthLevel2Completed) count++;
        if (brokenAuthLevel3Completed) count++;
        if (fileUploadLevel1Completed) count++;
        if (fileUploadLevel2Completed) count++;
        if (fileUploadLevel3Completed) count++;
        return count;
    }

    public String getRank() {
        if (xp >= 2700) return "Elite";
        if (xp >= 1500) return "Hacker";
        if (xp >= 500)  return "Apprentice";
        return "Beginner";
    }
}
