package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;

@Service
public class SqlInjectionChallengeService {

    public boolean checkLevel1(String payload) {
        if (payload == null) return false;
        String p = payload.toLowerCase().replaceAll("\\s+", "");
        return p.contains("'or'1'='1") || p.contains("\"or\"1\"=\"1");
    }

    public boolean checkLevel2(String payload) {
        if (payload == null) return false;
        String p = payload.toLowerCase().replaceAll("\\s+", "");
        return p.contains("or1=1") || p.contains("orid=1");
    }

    public boolean checkLevel3(String payload) {
        if (payload == null) return false;
        String p = payload.toLowerCase().replaceAll("\\s+", "");
        return p.contains("1=1") || p.contains("and1=1");
    }
}