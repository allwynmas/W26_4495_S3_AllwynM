package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.SqlInjectionChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/sql-injection")
public class SqlInjectionController {

    private final SqlInjectionChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public SqlInjectionController(SqlInjectionChallengeService challengeService,
                                  ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    // ── Helper: get or create progress row for the current user ──────────
    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    // ── GET /sql-injection ────────────────────────────────────────────────
    // Page is public — guests get an empty progress object so the template
    // renders without errors; their submissions are blocked at the POST level.
    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();

        model.addAttribute("progress", progress);
        return "pages/sql-injection/sqli";
    }

    // ── POST /sql-injection/level1 ────────────────────────────────────────
    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam String payload, Principal principal) {

        if (!challengeService.checkLevel1(payload)) {
            return new ChallengeResponse(false, "Try again. Hint: Use OR logic to make the condition always true.");
        }

        ChallengeProgress progress = getProgress(principal);

        // Award XP only on first completion
        if (!progress.isSqliLevel1Completed()) {
            progress.setSqliLevel1Completed(true);
            progress.addXp(100);
        }

        progressRepo.save(progress);
        return new ChallengeResponse(true, "Correct! You bypassed the WHERE clause. +100 XP");
    }

    // ── POST /sql-injection/level2 ────────────────────────────────────────
    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam String payload, Principal principal) {

        if (!challengeService.checkLevel2(payload)) {
            return new ChallengeResponse(false, "Incorrect. Try manipulating the numeric field with OR logic.");
        }

        ChallengeProgress progress = getProgress(principal);

        if (!progress.isSqliLevel2Completed()) {
            progress.setSqliLevel2Completed(true);
            progress.addXp(200);
        }

        progressRepo.save(progress);
        return new ChallengeResponse(true, "Nice! You manipulated the numeric ID. +200 XP");
    }

    // ── POST /sql-injection/level3 ────────────────────────────────────────
    @PostMapping("/level3")
    @ResponseBody
    public ChallengeResponse checkLevel3(@RequestParam String payload, Principal principal) {

        if (!challengeService.checkLevel3(payload)) {
            return new ChallengeResponse(false, "Not quite. Try boolean-based payloads that always evaluate to true.");
        }

        ChallengeProgress progress = getProgress(principal);

        if (!progress.isSqliLevel3Completed()) {
            progress.setSqliLevel3Completed(true);
            progress.addXp(300);

            // Award SQLi badge if all 3 levels now complete
            if (progress.isSqliLevel1Completed() && progress.isSqliLevel2Completed()) {
                progress.setSqlieBadgeEarned(true);
            }
        }

        progressRepo.save(progress);
        return new ChallengeResponse(true, "You successfully performed blind SQLi! +300 XP"
                + (progress.isSqlieBadgeEarned() ? " 🏆 SQL Slayer badge earned!" : ""));
    }
}