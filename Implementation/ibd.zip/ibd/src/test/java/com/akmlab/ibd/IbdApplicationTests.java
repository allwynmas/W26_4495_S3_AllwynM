package com.akmlab.ibd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbdApplicationTests {

	@Test
	void contextLoads() {
	}

}
