package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class IdorChallengeService {

    // Simulated user profile store — the "database" of profiles accessible by ID
    // The logged-in user is user ID 42. IDs 1–5 belong to other users including the admin (ID 1).
    private static final Map<Integer, String> PROFILES = Map.of(
            1,  "admin@example.com",
            2,  "alice@example.com",
            3,  "bob@example.com",
            4,  "charlie@example.com",
            5,  "diana@example.com",
            42, "you@example.com"
    );

    // Level 1 — Profile ID Manipulation
    // The student is logged in as user 42. They must access another user's profile
    // by changing the ID parameter to any value other than their own (42).
    public boolean checkLevel1(int profileId) {
        return profileId != 42 && PROFILES.containsKey(profileId);
    }

    // Returns the profile email for display — used in the success response
    public String getProfileEmail(int profileId) {
        return PROFILES.getOrDefault(profileId, "unknown");
    }

    // Level 2 — Admin Profile Access
    // The student must specifically reach the admin account (ID 1) by predicting
    // that the first registered user — the admin — has ID 1.
    public boolean checkLevel2(int profileId) {
        return profileId == 1;
    }
}