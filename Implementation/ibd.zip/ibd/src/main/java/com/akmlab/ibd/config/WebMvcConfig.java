package com.akmlab.ibd.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new CurrentUriInterceptor());
    }

    // Adds 'currentUri' to every page model so layout.html can use it
    // for the login redirect link without needing #request (removed in Thymeleaf 3.1)
    static class CurrentUriInterceptor implements HandlerInterceptor {

        @Override
        public void postHandle(HttpServletRequest request,
                               HttpServletResponse response,
                               Object handler,
                               ModelAndView modelAndView) {

            if (modelAndView != null) {
                modelAndView.addObject("currentUri", request.getRequestURI());
            }
        }
    }
}