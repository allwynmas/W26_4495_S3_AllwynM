package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Value;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class FileUploadChallengeService {

    // ── Level 1 ───────────────────────────────────────────────────────────
    // App accepts ANY file type — no validation at all.
    // Student just needs to upload an .html file containing a <script> tag.
    // We confirm the file has an .html or .htm extension AND contains a script tag.
    public boolean checkLevel1(MultipartFile file) {
        if (file == null || file.isEmpty()) return false;

        String filename = file.getOriginalFilename();
        if (filename == null) return false;

        String lower = filename.toLowerCase();
        if (!lower.endsWith(".html") && !lower.endsWith(".htm") && !lower.endsWith(".svg")) {
            return false;
        }

        try {
            String content = new String(file.getBytes()).toLowerCase();
            return content.contains("<script") || content.contains("onerror=") || content.contains("onload=");
        } catch (Exception e) {
            return false;
        }
    }

    // ── Level 2 ───────────────────────────────────────────────────────────
    // App checks Content-Type header only (client-supplied, easily spoofed).
    // Student uploads a file with a .jpg extension but HTML/script content inside.
    // Simulates bypassing a MIME-type-only check.
    public boolean checkLevel2(MultipartFile file) {
        if (file == null || file.isEmpty()) return false;

        String filename = file.getOriginalFilename();
        if (filename == null) return false;

        String lower = filename.toLowerCase();

        // Must look like an image by extension (the "bypass")
        boolean looksLikeImage = lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".png") || lower.endsWith(".gif");

        if (!looksLikeImage) return false;

        // But must contain a script/HTML payload inside (the actual attack)
        try {
            String content = new String(file.getBytes()).toLowerCase();
            return content.contains("<script") || content.contains("<html")
                    || content.contains("onerror=") || content.contains("onload=");
        } catch (Exception e) {
            return false;
        }
    }

    // ── Level 3 ───────────────────────────────────────────────────────────
    // App blocks dangerous extensions using a blacklist but student bypasses it
    // using a double extension (e.g. malicious.html.jpg  or  evil.jpg.html).
    // The last extension looks safe but the real payload extension is still there.
    public boolean checkLevel3(MultipartFile file) {
        if (file == null || file.isEmpty()) return false;

        String filename = file.getOriginalFilename();
        if (filename == null) return false;

        String lower = filename.toLowerCase();

        // Must have more than one dot (double extension)
        int firstDot = lower.indexOf('.');
        int lastDot  = lower.lastIndexOf('.');
        if (firstDot == lastDot) return false; // only one extension — not a bypass

        // The middle/first extension must be dangerous
        String middle = lower.substring(firstDot, lastDot); // e.g. ".html" or ".svg"
        boolean hasDangerousMiddle = middle.contains(".html") || middle.contains(".htm")
                || middle.contains(".svg") || middle.contains(".php")
                || middle.contains(".js");

        // The final extension must look safe (image/text)
        String finalExt = lower.substring(lastDot);
        boolean looksSafe = finalExt.equals(".jpg") || finalExt.equals(".jpeg")
                || finalExt.equals(".png") || finalExt.equals(".gif")
                || finalExt.equals(".txt");

        return hasDangerousMiddle && looksSafe;
    }

    // ── File Storage ──────────────────────────────────────────────────────
// Reads the upload directory from application.properties.
// This is intentionally insecure for the demo — no sanitisation,
// no content inspection, original extension preserved so browser
// will render it as HTML and execute any scripts inside.
//    @Value("${app.upload.dir}")
//    private String uploadDir;

    /**
     * Saves the uploaded file to the upload directory and returns the
     * filename it was saved under. We use a UUID prefix to avoid collisions
     * if two students upload a file with the same name, but we keep the
     * original extension so the browser serves it with the right MIME type.
     *
     * DELIBERATELY INSECURE: a safe implementation would strip the extension,
     * rename to a UUID only, and serve with Content-Disposition: attachment.
     */
//    public String saveFile(MultipartFile file) throws IOException {
        // Create the uploads folder if it doesn't exist yet
    public String saveFile(MultipartFile file, String uploadDir) throws IOException {

        Path uploadPath = Paths.get(uploadDir);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        // Keep original filename but prefix with UUID to avoid collisions
        // e.g. "a3f9c1-payload.html" — extension preserved on purpose
        String originalName = file.getOriginalFilename();
        String savedName = UUID.randomUUID().toString().substring(0, 8) + "-" + originalName;

        Path filePath = uploadPath.resolve(savedName);
        Files.write(filePath, file.getBytes());

        return savedName;
    }
}
