package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@Service
public class SqlInjectionChallengeService {

    private final DataSource dataSource;

    public SqlInjectionChallengeService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // ── Result record returned to the controller ──────────────────────────
    public record ChallengeResult(boolean success, String builtQuery, String errorHint) {
        public static ChallengeResult fail(String hint) {
            return new ChallengeResult(false, null, hint);
        }
        public static ChallengeResult failWithQuery(String query, String hint) {
            return new ChallengeResult(false, query, hint);
        }
        public static ChallengeResult pass(String query) {
            return new ChallengeResult(true, query, null);
        }
    }

    // ── Level 1 — OR Injection ────────────────────────────────────────────
    // Vulnerable query: SELECT * FROM sqli_users WHERE username = 'USER_INPUT'
    // Success condition: query returns more than 1 row (bypassed the WHERE clause)
    public ChallengeResult checkLevel1(String payload) {
        if (payload == null || payload.isBlank()) {
            return ChallengeResult.fail("Please enter a payload.");
        }

        String query = "SELECT * FROM sqli_users WHERE username = '" + payload + "'";

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            // Prevent destructive statements
            String upper = payload.toUpperCase();
            if (upper.contains("DROP") || upper.contains("DELETE")
                    || upper.contains("UPDATE") || upper.contains("INSERT")) {
                return ChallengeResult.fail(
                        "Destructive statements are not allowed in this challenge.");
            }

            ResultSet rs = stmt.executeQuery(query);
            int rowCount = 0;
            while (rs.next()) rowCount++;

            if (rowCount > 1) {
                return ChallengeResult.pass(query);
            } else {
                return ChallengeResult.failWithQuery(query,
                        "The query ran but only returned " + rowCount + " row(s). "
                                + "You need to make the WHERE clause return ALL users. "
                                + "Hint: use OR logic to make the condition always true.");
            }

        } catch (Exception e) {
            // SQL syntax error — give a nudge
            return ChallengeResult.failWithQuery(query,
                    "Your payload caused a SQL error. Check your quote characters and try again.");
        }
    }

    // ── Level 2 — Numeric Injection ───────────────────────────────────────
    // Vulnerable query: SELECT * FROM sqli_products WHERE id = USER_INPUT
    // Success condition: query returns more than 1 row (no quotes — numeric context)
    public ChallengeResult checkLevel2(String payload) {
        if (payload == null || payload.isBlank()) {
            return ChallengeResult.fail("Please enter a payload.");
        }

        String query = "SELECT * FROM sqli_products WHERE id = " + payload;

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            String upper = payload.toUpperCase();
            if (upper.contains("DROP") || upper.contains("DELETE")
                    || upper.contains("UPDATE") || upper.contains("INSERT")) {
                return ChallengeResult.fail(
                        "Destructive statements are not allowed in this challenge.");
            }

            ResultSet rs = stmt.executeQuery(query);
            int rowCount = 0;
            while (rs.next()) rowCount++;

            if (rowCount > 1) {
                return ChallengeResult.pass(query);
            } else {
                return ChallengeResult.failWithQuery(query,
                        "The query ran but only returned " + rowCount + " row(s). "
                                + "Notice there are no quotes around the input — this is a numeric field. "
                                + "Hint: inject OR logic directly without quote characters.");
            }

        } catch (Exception e) {
            return ChallengeResult.failWithQuery(query,
                    "Your payload caused a SQL error. Remember: no quotes needed for numeric fields.");
        }
    }

    // ── Level 3 — Blind Boolean SQLi ──────────────────────────────────────
    // Vulnerable query: SELECT * FROM sqli_users WHERE id = USER_INPUT
    // App only reveals true/false — not data.
    // Success condition: query returns at least 1 row AND payload uses boolean logic
    // (not just a plain id like "1")
    public ChallengeResult checkLevel3(String payload) {
        if (payload == null || payload.isBlank()) {
            return ChallengeResult.fail("Please enter a payload.");
        }

        // Reject plain numeric input — must use boolean injection
        if (payload.trim().matches("\\d+")) {
            return ChallengeResult.fail(
                    "That's just a normal ID lookup — any valid ID would return true. "
                            + "You need to craft a boolean injection that would be true for ANY id value. "
                            + "Hint: use AND or OR with a condition that always evaluates to true.");
        }

        String query = "SELECT * FROM sqli_users WHERE id = " + payload;

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            String upper = payload.toUpperCase();
            if (upper.contains("DROP") || upper.contains("DELETE")
                    || upper.contains("UPDATE") || upper.contains("INSERT")) {
                return ChallengeResult.fail(
                        "Destructive statements are not allowed in this challenge.");
            }

            ResultSet rs = stmt.executeQuery(query);
            boolean hasRows = rs.next();

            // Must also contain boolean logic keywords to count as blind SQLi
            String lower = payload.toLowerCase();
            boolean hasBooleanLogic = lower.contains(" and ") || lower.contains(" or ")
                    || lower.contains("--") || lower.contains("/*");

            if (hasRows && hasBooleanLogic) {
                return ChallengeResult.pass(query);
            } else if (!hasRows) {
                return ChallengeResult.failWithQuery(query,
                        "The query returned no rows — your condition evaluated to false. "
                                + "Hint: use AND with a tautology like 1=1.");
            } else {
                return ChallengeResult.failWithQuery(query,
                        "The query returned a row, but try using explicit boolean logic "
                                + "(AND/OR) to demonstrate blind injection technique.");
            }

        } catch (Exception e) {
            return ChallengeResult.failWithQuery(query,
                    "Your payload caused a SQL error. Check your syntax and try again.");
        }
    }
}