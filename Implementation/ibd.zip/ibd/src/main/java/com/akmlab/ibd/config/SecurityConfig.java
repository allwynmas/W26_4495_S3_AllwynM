package com.akmlab.ibd.config;

import com.akmlab.ibd.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

import java.io.IOException;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final UserService userService;

    // @Lazy avoids a circular dependency:
    // SecurityConfig → UserService → PasswordEncoder → SecurityConfig
    public SecurityConfig(@Lazy UserService userService) {
        this.userService = userService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Wires UserService + PasswordEncoder into Spring Security's auth flow
    @Bean
    public DaoAuthenticationProvider authProvider(PasswordEncoder encoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userService);
        provider.setPasswordEncoder(encoder);
        return provider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                .authenticationProvider(authProvider(passwordEncoder()))
                .authorizeHttpRequests(auth -> auth
                        // Static assets — always public
                        .requestMatchers("/css/**", "/js/**", "/images/**", "/file-upload/uploads/**").permitAll()
                        // Auth pages — public
                        .requestMatchers("/login", "/signup", "/h2-console/**").permitAll()
                        // Informational pages — public
                        .requestMatchers("/", "/owasp", "/challenges", "/about").permitAll()
                        // Vulnerability pages (GET) — public so guests can read the Learn tab
                        .requestMatchers("GET", "/sql-injection", "/xss/reflected", "/csrf", "/idor", "/broken-auth", "/file-upload").permitAll()
                        // Challenge submissions (POST) — require login
                        .requestMatchers("POST", "/sql-injection/**", "/xss/**", "/csrf/**", "/idor/**", "/broken-auth/**", "/file-upload/**").authenticated()
                        // Everything else (profile etc.) — requires login
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .successHandler(new RedirectAfterLoginHandler())
                        .failureUrl("/login?error")
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessHandler((request, response, authentication) -> {
                            // Short-lived cookie triggers the toast on the home page
                            Cookie cookie = new Cookie("justLoggedOut", "true");
                            cookie.setMaxAge(10);
                            cookie.setPath("/");
                            response.addCookie(cookie);
                            response.sendRedirect("/");
                        })
                        .invalidateHttpSession(true)
                        .deleteCookies("JSESSIONID")
                        .clearAuthentication(true)
                        .permitAll()
                )
                .csrf(csrf -> csrf.disable())
                .headers(headers -> headers.frameOptions(frame -> frame.disable()));

        return http.build();
    }

    // ── After login: honour ?redirect param, otherwise go home ───────────
    static class RedirectAfterLoginHandler extends SimpleUrlAuthenticationSuccessHandler {

        @Override
        public void onAuthenticationSuccess(HttpServletRequest request,
                                            HttpServletResponse response,
                                            Authentication authentication) throws IOException {
            String redirect = request.getParameter("redirect");

            // Only allow safe relative paths to prevent open redirect attacks
            if (redirect != null && redirect.startsWith("/") && !redirect.contains("//")) {
                response.sendRedirect(redirect);
            } else {
                response.sendRedirect("/");
            }
        }
    }
}