package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;

@Service
public class CsrfChallengeService {

    // Level 1 — Forged Form Submission
    // Simulates a state-changing action (email change) that has no CSRF token.
    // Student must submit a forged action targeting the victim's account.
    // We accept any non-blank email that looks like a forged attacker-controlled address.
    public boolean checkLevel1(String forgedEmail) {
        if (forgedEmail == null || forgedEmail.isBlank()) return false;
        String e = forgedEmail.trim().toLowerCase();
        // Accept any email that is not the victim's own address — simulating an attacker-controlled value
        return e.contains("@") && !e.equals("victim@example.com");
    }

    // Level 2 — Predictable / Missing Token Bypass
    // The app now adds a CSRF token, but it's static and hardcoded — trivially guessable.
    // Student must submit the correct static token to simulate bypassing the weak protection.
    private static final String WEAK_TOKEN = "csrf_token_123";

    public boolean checkLevel2(String token) {
        if (token == null) return false;
        return token.trim().equals(WEAK_TOKEN);
    }
}