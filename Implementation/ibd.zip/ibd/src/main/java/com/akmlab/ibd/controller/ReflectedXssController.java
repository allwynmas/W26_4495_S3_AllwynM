package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.XssChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/xss/reflected")
public class ReflectedXssController {

    private final XssChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public ReflectedXssController(XssChallengeService challengeService,
                                  ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    // ── GET /xss/reflected ────────────────────────────────────────────────
    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();
        model.addAttribute("progress", progress);
        return "pages/xss/reflected";
    }

    // ── POST /xss/reflected/level1 — Basic Script Injection ───────────────
    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam String payload, Principal principal) {
        if (!challengeService.checkLevel1(payload)) {
            return new ChallengeResponse(false,
                    "Not quite. Hint: inject a &lt;script&gt; tag that calls alert().");
        }
        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isXssLevel1Completed();
        if (firstTime) {
            progress.setXssLevel1Completed(true);
            progress.addXp(100);
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true,
                "&#x2713; Script injected!" + (firstTime ? " +100 XP" : "") + buildWhyItWorked1(payload));
    }

    // ── POST /xss/reflected/level2 — Filter Bypass ────────────────────────
    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam String payload, Principal principal) {
        if (!challengeService.checkLevel2(payload)) {
            String hint = (payload != null && payload.toLowerCase().contains("<script"))
                    ? "The &lt;script&gt; tag was stripped by the filter. Try an element with an event handler like onerror or onload."
                    : "Not quite. Hint: use an HTML element with an event-handler attribute — no &lt;script&gt; needed.";
            return new ChallengeResponse(false, hint);
        }
        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isXssLevel2Completed();
        if (firstTime) {
            progress.setXssLevel2Completed(true);
            progress.addXp(200);
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true,
                "&#x2713; Filter bypassed!" + (firstTime ? " +200 XP" : "") + buildWhyItWorked2(payload));
    }

    // ── POST /xss/reflected/level3 — Attribute Injection ──────────────────
    @PostMapping("/level3")
    @ResponseBody
    public ChallengeResponse checkLevel3(@RequestParam String payload, Principal principal) {
        if (!challengeService.checkLevel3(payload)) {
            String hint = (payload != null && (payload.contains("<") || payload.contains(">")))
                    ? "Angle brackets were stripped. You can't use tags — break out of the attribute value with a quote character instead."
                    : "Not quite. Hint: close the attribute with \" then inject an event handler like onmouseover=\"alert(1).";
            return new ChallengeResponse(false, hint);
        }
        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isXssLevel3Completed();
        if (firstTime) {
            progress.setXssLevel3Completed(true);
            progress.addXp(300);
            if (progress.isXssLevel1Completed() && progress.isXssLevel2Completed()) {
                progress.setXssBadgeEarned(true);
            }
        }
        progressRepo.save(progress);
        String badge = progress.isXssBadgeEarned() ? " &#x1F3C6; Script Kiddie badge earned!" : "";
        return new ChallengeResponse(true,
                "&#x2713; Attribute injection successful!" + (firstTime ? " +300 XP" : "") + badge + buildWhyItWorked3(payload));
    }

    // ── "Why It Worked" builders ──────────────────────────────────────────

    private String buildWhyItWorked1(String payload) {
        return "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The page rendered your input as raw HTML using <code>th:utext</code>:</div>"
                + "<div class='why-code'>&lt;span th:utext=\"${query}\"&gt;&lt;/span&gt;</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "Your payload was inserted directly: <code>" + escHtml(payload) + "</code></div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The browser parsed the <code>&lt;script&gt;</code> tag as executable code and ran <code>alert()</code> immediately.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "In a real attack, an attacker would send a victim a crafted URL — when they open it, the script runs in <strong>their</strong> browser under the site's origin, giving access to cookies and session tokens.</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Use <code>th:text</code> instead of <code>th:utext</code>. "
                + "It HTML-encodes the output so <code>&lt;script&gt;</code> is displayed as text, never executed.</div>"
                + "</div>";
    }

    private String buildWhyItWorked2(String payload) {
        // Simulate the filter the server applies
        String filtered = payload.replaceAll("(?i)<script[\\s\\S]*?>[\\s\\S]*?</script>", "");
        return "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The server stripped <code>&lt;script&gt;</code> tags — but still rendered the output with <code>th:utext</code>:</div>"
                + "<div class='why-code'>input = input.replaceAll(\"(?i)&lt;script[\\\\s\\\\S]*?&gt;...\", \"\");\n"
                + "&lt;span th:utext=\"${filtered}\"&gt;&lt;/span&gt;</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "After filtering, your payload became: <code>" + escHtml(filtered) + "</code></div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The browser still executed the event handler — <code>&lt;script&gt;</code> is just one of many ways to run JavaScript. "
                + "Event handlers on HTML elements like <code>onerror</code> and <code>onload</code> work just as well.</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Stripping specific tags is not a safe defence — attackers always find alternative vectors. "
                + "The only reliable fix is <code>th:text</code> which encodes <strong>all</strong> HTML characters regardless of the payload shape.</div>"
                + "</div>";
    }

    private String buildWhyItWorked3(String payload) {
        // Simulate the filter — strip angle brackets
        String filtered = payload.replace("<", "").replace(">", "");
        return "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The server stripped <code>&lt;</code> and <code>&gt;</code> — but the input was reflected inside an HTML attribute:</div>"
                + "<div class='why-code'>&lt;input type=\"text\" value=\"" + escHtml(filtered) + "\"&gt;</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "By injecting a <code>\"</code> you closed the <code>value</code> attribute early. "
                + "Everything after it was interpreted as new HTML attributes on the same element.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "Event handlers like <code>onmouseover</code> can be added directly to any HTML element — "
                + "no angle brackets needed, so the filter was completely bypassed.</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Use <code>th:value</code> for attribute output — "
                + "Thymeleaf automatically encodes quotes in attribute contexts, making it impossible to break out of the attribute value.</div>"
                + "</div>";
    }

    // ── HTML escape helper ────────────────────────────────────────────────
    private String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}