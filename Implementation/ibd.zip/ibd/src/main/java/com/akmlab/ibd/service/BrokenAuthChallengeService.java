package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;
import java.util.Base64;
import java.util.Set;

@Service
public class BrokenAuthChallengeService {

    // Level 1 — weak/default credentials
    // Student must submit admin:admin, admin:password, root:root, etc.
    private static final Set<String> WEAK_COMBOS = Set.of(
            "admin:admin",
            "admin:password",
            "admin:1234",
            "root:root",
            "root:toor",
            "administrator:admin"
    );

    public boolean checkLevel1(String username, String password) {
        if (username == null || password == null) return false;
        String combo = username.trim().toLowerCase() + ":" + password.trim().toLowerCase();
        return WEAK_COMBOS.contains(combo);
    }

    // Level 2 — predictable session token
    // Student must submit a sequential ID, base64("admin"), or trivially guessable token
    private static final Set<String> WEAK_TOKENS = Set.of(
            "user-1",
            "session-1",
            "1",
            "admin",
            "dXNlcjE=",   // base64("user1")
            "YWRtaW4="    // base64("admin")
    );

    public boolean checkLevel2(String token) {
        if (token == null) return false;
        String t = token.trim();

        // Accept any of the known weak tokens
        if (WEAK_TOKENS.contains(t)) return true;

        // Also accept if it decodes cleanly to a simple word (base64 check)
        try {
            String decoded = new String(Base64.getDecoder().decode(t)).toLowerCase();
            return decoded.equals("admin") || decoded.equals("user1")
                    || decoded.equals("user-1") || decoded.equals("session1");
        } catch (IllegalArgumentException e) {
            // Not valid base64 — that's fine, still check other cases
        }

        // Accept sequential numeric-style tokens: session-1, session-2, user-1 etc.
        return t.matches("(user|session|token|id)-?\\d+");
    }

    // Level 3 — credential stuffing
    // Student submits a known breach email:password combo
    private static final Set<String> BREACH_COMBOS = Set.of(
            "john.doe@example.com:password123",
            "jane.doe@example.com:qwerty123",
            "test@test.com:test1234",
            "user@example.com:welcome1"
    );

    public boolean checkLevel3(String email, String password) {
        if (email == null || password == null) return false;
        String combo = email.trim().toLowerCase() + ":" + password.trim();
        return BREACH_COMBOS.contains(combo);
    }
}