package com.akmlab.ibd.service;

import org.springframework.stereotype.Service;

@Service
public class XssChallengeService {

    /**
     * Level 1 — Basic Script Injection
     * No filter. Payload must contain a <script> tag with alert().
     */
    public boolean checkLevel1(String payload) {
        if (payload == null || payload.isBlank()) return false;
        String p = payload.toLowerCase();
        boolean hasScriptOpen  = p.contains("<script");
        boolean hasScriptClose = p.contains("</script>");
        boolean hasAlert       = p.contains("alert(");
        return hasScriptOpen && hasScriptClose && hasAlert;
    }

    /**
     * Level 2 — Filter Bypass
     * Server strips full <script>...</script> blocks (regex, case-insensitive).
     * Payload must NOT rely on script tags — must use an event-handler attribute.
     * Valid examples: <img src=x onerror=alert(1)>, <svg onload=alert(1)>
     */
    public boolean checkLevel2(String payload) {
        if (payload == null || payload.isBlank()) return false;

        // Simulate the server-side filter
        String filtered = payload.replaceAll("(?i)<script[\\s\\S]*?>[\\s\\S]*?</script>", "");

        String f = filtered.toLowerCase();

        // After filtering, must still contain an event handler attribute
        boolean hasEventHandler = f.matches("(?s).*\\bon(error|load|click|mouseover|focus|input|submit)\\s*=.*");

        // Reject if they just stuffed alert in something that got stripped anyway
        boolean hasPayload = f.contains("alert(") || f.contains("prompt(") || f.contains("confirm(")
                || f.contains("document.cookie") || f.contains("javascript:");

        return hasEventHandler && hasPayload;
    }

    /**
     * Level 3 — Attribute Injection
     * Server strips angle brackets: < and > are removed.
     * Input is reflected inside an HTML attribute: <input value="USER_INPUT">
     * Payload must break out of the attribute using a quote, then add an event handler.
     * Valid example: " onmouseover="alert(1)
     */
    public boolean checkLevel3(String payload) {
        if (payload == null || payload.isBlank()) return false;

        // Simulate the server-side filter — strip angle brackets
        String filtered = payload.replace("<", "").replace(">", "");

        String f = filtered.toLowerCase();

        // Must break out of the attribute with a quote
        boolean breaksAttribute = f.contains("\"") || f.contains("'");

        // Must contain an event handler
        boolean hasEventHandler = f.matches("(?s).*\\bon(error|load|click|mouseover|focus|input|submit)\\s*=.*");

        // Must contain some JS execution
        boolean hasPayload = f.contains("alert(") || f.contains("prompt(") || f.contains("confirm(")
                || f.contains("document.cookie") || f.contains("javascript:");

        return breaksAttribute && hasEventHandler && hasPayload;
    }
}