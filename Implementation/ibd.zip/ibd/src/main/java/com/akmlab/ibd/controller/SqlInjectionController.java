package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.SqlInjectionChallengeService;
import com.akmlab.ibd.service.SqlInjectionChallengeService.ChallengeResult;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/sql-injection")
public class SqlInjectionController {

    private final SqlInjectionChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public SqlInjectionController(SqlInjectionChallengeService challengeService,
                                  ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    // ── GET /sql-injection ────────────────────────────────────────────────
    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();
        model.addAttribute("progress", progress);
        return "pages/sql-injection/sqli";
    }

    // ── POST /sql-injection/level1 ────────────────────────────────────────
    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam String payload, Principal principal) {
        ChallengeResult result = challengeService.checkLevel1(payload);

        if (!result.success()) {
            String msg = result.errorHint();
            if (result.builtQuery() != null) {
                msg += "<div class='why-query'>Built query: <code>" + escHtml(result.builtQuery()) + "</code></div>";
            }
            return new ChallengeResponse(false, msg);
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isSqliLevel1Completed();
        if (firstTime) {
            progress.setSqliLevel1Completed(true);
            progress.addXp(100);
        }
        progressRepo.save(progress);

        String why = buildWhyItWorked1(payload, result.builtQuery());
        return new ChallengeResponse(true,
                "&#x2713; You bypassed the WHERE clause!" + (firstTime ? " +100 XP" : "") + why);
    }

    // ── POST /sql-injection/level2 ────────────────────────────────────────
    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam String payload, Principal principal) {
        ChallengeResult result = challengeService.checkLevel2(payload);

        if (!result.success()) {
            String msg = result.errorHint();
            if (result.builtQuery() != null) {
                msg += "<div class='why-query'>Built query: <code>" + escHtml(result.builtQuery()) + "</code></div>";
            }
            return new ChallengeResponse(false, msg);
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isSqliLevel2Completed();
        if (firstTime) {
            progress.setSqliLevel2Completed(true);
            progress.addXp(200);
        }
        progressRepo.save(progress);

        String why = buildWhyItWorked2(payload, result.builtQuery());
        return new ChallengeResponse(true,
                "&#x2713; Numeric injection successful!" + (firstTime ? " +200 XP" : "") + why);
    }

    // ── POST /sql-injection/level3 ────────────────────────────────────────
    @PostMapping("/level3")
    @ResponseBody
    public ChallengeResponse checkLevel3(@RequestParam String payload, Principal principal) {
        ChallengeResult result = challengeService.checkLevel3(payload);

        if (!result.success()) {
            String msg = result.errorHint();
            if (result.builtQuery() != null) {
                msg += "<div class='why-query'>Built query: <code>" + escHtml(result.builtQuery()) + "</code></div>";
            }
            return new ChallengeResponse(false, msg);
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isSqliLevel3Completed();
        if (firstTime) {
            progress.setSqliLevel3Completed(true);
            progress.addXp(300);
            if (progress.isSqliLevel1Completed() && progress.isSqliLevel2Completed()) {
                progress.setSqlieBadgeEarned(true);
            }
        }
        progressRepo.save(progress);

        String badge = progress.isSqlieBadgeEarned() ? " &#x1F3C6; SQL Slayer badge earned!" : "";
        String why = buildWhyItWorked3(payload, result.builtQuery());
        return new ChallengeResponse(true,
                "&#x2713; Blind boolean injection confirmed!" + (firstTime ? " +300 XP" : "") + badge + why);
    }

    // ── "Why It Worked" builders ──────────────────────────────────────────

    private String buildWhyItWorked1(String payload, String query) {
        return "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "Your input was inserted directly into the query string:</div>"
                + "<div class='why-code'>" + escHtml(query) + "</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "<code>username = ''</code> evaluates to <strong>false</strong> — no user has a blank username.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "<code>OR '1'='1'</code> evaluates to <strong>always true</strong> — every row passes the check.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "<strong>false OR true = true</strong> — the WHERE clause returned every user in the table.</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Use a PreparedStatement. "
                + "<code>WHERE username = ?</code> treats input as data — quotes and keywords are never interpreted as SQL.</div>"
                + "</div>";
    }

    private String buildWhyItWorked2(String payload, String query) {
        return "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The ID field has no quotes — input is injected directly as a numeric expression:</div>"
                + "<div class='why-code'>" + escHtml(query) + "</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "Because there are no surrounding quotes, you can inject SQL keywords directly without breaking out of a string.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The <code>OR 1=1</code> condition is always true — so all products are returned, including hidden ones.</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Use a PreparedStatement with <code>WHERE id = ?</code> "
                + "and set the parameter as an integer — SQL keywords in input are never executed.</div>"
                + "</div>";
    }

    private String buildWhyItWorked3(String payload, String query) {
        return "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The app only reveals true/false — no data is shown. But you can still infer behavior:</div>"
                + "<div class='why-code'>" + escHtml(query) + "</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "By injecting a condition that is <strong>always true</strong> (e.g. <code>AND 1=1</code>), "
                + "you confirmed the endpoint is injectable — it returned true regardless of the ID value.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "In real blind SQLi, attackers use this technique to extract data one bit at a time "
                + "by asking true/false questions like <code>AND SUBSTRING(username,1,1)='a'</code>.</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Parameterized queries — <code>WHERE id = ?</code> "
                + "with an integer parameter makes boolean injection impossible.</div>"
                + "</div>";
    }

    // ── HTML escape helper ────────────────────────────────────────────────
    private String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}