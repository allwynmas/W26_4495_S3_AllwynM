package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.CsrfChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/csrf")
public class CsrfController {

    private final CsrfChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public CsrfController(CsrfChallengeService challengeService,
                          ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();
        model.addAttribute("progress", progress);
        return "pages/csrf/csrf";
    }

    // Level 1 — Forged Form Submission (no token at all)
    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam String forgedEmail,
                                         Principal principal) {
        if (!challengeService.checkLevel1(forgedEmail)) {
            return new ChallengeResponse(false,
                    "Not quite. Think about what value an attacker would forge in place of the victim's email.");
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isCsrfLevel1Completed();
        if (firstTime) {
            progress.setCsrfLevel1Completed(true);
            progress.addXp(100);
        }
        progressRepo.save(progress);

        String why = "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The endpoint performs a state-changing action (email update) with no token to verify the request originated from the real user.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "An attacker hosts a page with a hidden form pointing at this endpoint. When the victim visits it while logged in, their browser automatically sends their session cookie — the server can't tell it was forged.</div>"
                + "<div class='why-code'>&lt;form action=\"https://victim-site.com/account/email\" method=\"POST\"&gt;\n"
                + "  &lt;input type=\"hidden\" name=\"email\" value=\"attacker@evil.com\"&gt;\n"
                + "&lt;/form&gt;\n"
                + "&lt;script&gt;document.forms[0].submit();&lt;/script&gt;</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Include a cryptographically random CSRF token in every state-changing form and validate it server-side. Spring Security does this automatically when CSRF protection is enabled.</div>"
                + "</div>";

        return new ChallengeResponse(true,
                "&#x2713; Forged request accepted!" + (firstTime ? " +100 XP" : "") + why);
    }

    // Level 2 — Static / predictable token bypass
    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam String csrfToken,
                                         Principal principal) {
        if (!challengeService.checkLevel2(csrfToken)) {
            return new ChallengeResponse(false,
                    "Wrong token. Look carefully at the page source — static tokens are meant to be found.");
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isCsrfLevel2Completed();
        if (firstTime) {
            progress.setCsrfLevel2Completed(true);
            progress.addXp(200);
            if (progress.isCsrfLevel1Completed()) {
                progress.setCsrfBadgeEarned(true);
            }
        }
        progressRepo.save(progress);

        String badge = progress.isCsrfBadgeEarned() ? " &#x1F3C6; Forgery Expert badge earned!" : "";
        String why = "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The developer added a CSRF token — but it's a hardcoded static string, the same for every user and every request.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "An attacker can read the token from the page source once and reuse it indefinitely in forged requests.</div>"
                + "<div class='why-code'>// Vulnerable — static token, same for everyone\n"
                + "private static final String CSRF_TOKEN = \"csrf_token_123\";</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> CSRF tokens must be cryptographically random, unique per session (ideally per request), and validated server-side on every state-changing request. Never hardcode them.</div>"
                + "</div>";

        return new ChallengeResponse(true,
                "&#x2713; Static token bypassed!" + (firstTime ? " +200 XP" : "") + badge + why);
    }
}