package com.akmlab.ibd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbdApplication {

	public static void main(String[] args) {

		SpringApplication.run(IbdApplication.class, args);
	}



}
