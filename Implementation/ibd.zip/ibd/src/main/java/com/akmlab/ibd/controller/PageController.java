package com.akmlab.ibd.controller;

import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;

@Controller
public class PageController {

    private final UserService userService;
    private final ChallengeProgressRepository progressRepo;

    public PageController(UserService userService, ChallengeProgressRepository progressRepo) {
        this.userService = userService;
        this.progressRepo = progressRepo;
    }

    // ── Public pages ──────────────────────────────────────────────────────

    @GetMapping("/")
    public String home(Model model, Principal principal) {
        model.addAttribute("isLoggedIn", principal != null);
        return "pages/home";
    }

    @GetMapping("/login")
    public String login() {
        return "pages/login";
    }

    @GetMapping("/signup")
    public String signupPage() {
        return "pages/signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam String username,
                         @RequestParam String password,
                         Model model) {

        UserService.SignupResult result = userService.signup(username, password);

        switch (result) {
            case SUCCESS:
                return "redirect:/login?registered";
            case USERNAME_TAKEN:
                model.addAttribute("error", "Username '" + username + "' is already taken.");
                model.addAttribute("username", username);
                return "pages/signup";
            case INVALID_INPUT:
                model.addAttribute("error", "Username must be 3–30 characters and password at least 6 characters.");
                model.addAttribute("username", username);
                return "pages/signup";
            default:
                return "pages/signup";
        }
    }


    @GetMapping("/owasp")
    public String owasp() {
        return "pages/owasp";
    }

    @GetMapping("/about")
    public String about() {
        return "pages/about";
    }

    // ── Challenge Hub ─────────────────────────────────────────────────────

    @GetMapping("/challenges")
    public String challenges(Model model, Principal principal) {
        if (principal != null) {
            ChallengeProgress progress = progressRepo.findByUsername(principal.getName())
                    .orElseGet(() -> progressRepo.save(new ChallengeProgress(principal.getName())));
            model.addAttribute("progress", progress);
        }
        return "pages/challenges";
    }

    // ── Profile (login required) ──────────────────────────────────────────

    @GetMapping("/profile")
    public String profile(Model model, Principal principal) {
        ChallengeProgress progress = progressRepo.findByUsername(principal.getName())
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(principal.getName())));

        model.addAttribute("username", principal.getName());
        model.addAttribute("progress", progress);

        // Calculate XP progress to next rank
        int xp = progress.getXp();
        int[] thresholds = {0, 300, 800, 1500};
        String[] ranks = {"Beginner", "Apprentice", "Hacker", "Elite"};

        int currentTier = 0;
        for (int i = thresholds.length - 1; i >= 0; i--) {
            if (xp >= thresholds[i]) { currentTier = i; break; }
        }

        if (currentTier < ranks.length - 1) {
            int from = thresholds[currentTier];
            int to = thresholds[currentTier + 1];
            model.addAttribute("nextRank", ranks[currentTier + 1]);
            model.addAttribute("rankProgress", (xp - from) * 100 / (to - from));
            model.addAttribute("xpToNextRank", to - xp);
        } else {
            model.addAttribute("nextRank", "Elite (Max)");
            model.addAttribute("rankProgress", 100);
            model.addAttribute("xpToNextRank", 0);
        }

        return "pages/profile";
    }
}