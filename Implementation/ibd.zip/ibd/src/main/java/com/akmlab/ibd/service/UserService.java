package com.akmlab.ibd.service;

import com.akmlab.ibd.model.User;
import com.akmlab.ibd.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ── Called by Spring Security on every login attempt ──────────────────
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .roles("USER")
                .build();
    }

    // ── Called on signup ──────────────────────────────────────────────────
    public enum SignupResult { SUCCESS, USERNAME_TAKEN, INVALID_INPUT }

    public SignupResult signup(String username, String password) {
        if (username == null || username.isBlank() ||
                password == null || password.isBlank()) {
            return SignupResult.INVALID_INPUT;
        }

        if (username.length() < 3 || username.length() > 30) {
            return SignupResult.INVALID_INPUT;
        }

        if (password.length() < 6) {
            return SignupResult.INVALID_INPUT;
        }

        if (userRepository.existsByUsername(username)) {
            return SignupResult.USERNAME_TAKEN;
        }

        User user = new User(username, passwordEncoder.encode(password));
        userRepository.save(user);
        return SignupResult.SUCCESS;
    }
}