package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.IdorChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/idor")
public class IdorController {

    private final IdorChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public IdorController(IdorChallengeService challengeService,
                          ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();
        model.addAttribute("progress", progress);
        return "pages/idor/idor";
    }

    // Level 1 — Access another user's profile by changing the ID
    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam int profileId,
                                         Principal principal) {
        if (!challengeService.checkLevel1(profileId)) {
            return new ChallengeResponse(false,
                    "That ID doesn't resolve to another user's profile. Try a different value.");
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isIdorLevel1Completed();
        if (firstTime) {
            progress.setIdorLevel1Completed(true);
            progress.addXp(100);
        }
        progressRepo.save(progress);

        String email = challengeService.getProfileEmail(profileId);
        String why = "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "The endpoint fetches a profile using a user-supplied ID with no check that it belongs to the logged-in user.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "You accessed the profile of <strong>" + escHtml(email) + "</strong> simply by changing the ID in the request.</div>"
                + "<div class='why-code'>// Vulnerable\n"
                + "Profile profile = profileRepo.findById(profileId); // no ownership check\n"
                + "return profile;</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Always verify the requested object belongs to the authenticated user. "
                + "<code>if (!profile.getOwner().equals(currentUser)) throw new AccessDeniedException();</code></div>"
                + "</div>";

        return new ChallengeResponse(true,
                "&#x2713; You accessed another user's profile!" + (firstTime ? " +100 XP" : "") + why);
    }

    // Level 2 — Access the admin profile by predicting ID 1
    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam int profileId,
                                         Principal principal) {
        if (!challengeService.checkLevel2(profileId)) {
            return new ChallengeResponse(false,
                    "Not the admin profile. Think about what ID the very first registered user would have.");
        }

        ChallengeProgress progress = getProgress(principal);
        boolean firstTime = !progress.isIdorLevel2Completed();
        if (firstTime) {
            progress.setIdorLevel2Completed(true);
            progress.addXp(200);
            if (progress.isIdorLevel1Completed()) {
                progress.setIdorBadgeEarned(true);
            }
        }
        progressRepo.save(progress);

        String badge = progress.isIdorBadgeEarned() ? " &#x1F3C6; Reference Manipulator badge earned!" : "";
        String why = "<div class='why-it-worked'>"
                + "<div class='why-title'>&#x1F50D; Why it worked</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "Auto-incremented database IDs are sequential and predictable — the first user (the admin) almost always has ID 1.</div>"
                + "<div class='why-row'><span class='why-arrow'>&#x2192;</span>"
                + "With no authorisation check on the endpoint, any authenticated user can access any record just by knowing or guessing its ID.</div>"
                + "<div class='why-code'>GET /profile?id=1  →  returns admin profile\n"
                + "GET /profile?id=2  →  returns alice's profile\n"
                + "// No check: does this ID belong to the current user?</div>"
                + "<div class='why-fix'>&#x1F527; <strong>The fix:</strong> Use non-sequential identifiers (UUIDs) for sensitive resources, and always enforce object-level authorisation — verify ownership on every request regardless of the ID format.</div>"
                + "</div>";

        return new ChallengeResponse(true,
                "&#x2713; Admin profile accessed via sequential ID!" + (firstTime ? " +200 XP" : "") + badge + why);
    }

    private String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}