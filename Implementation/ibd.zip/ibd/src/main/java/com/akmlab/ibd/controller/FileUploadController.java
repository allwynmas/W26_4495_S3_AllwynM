package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.FileUploadChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.security.Principal;

@Controller
@RequestMapping("/file-upload")
public class FileUploadController {

    // Inject the upload directory path from application.properties
// This is needed here so we can pass it to the service's saveFile() method
    @Value("${app.upload.dir}")
    private String uploadDir;

    private final FileUploadChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public FileUploadController(FileUploadChallengeService challengeService,
                                ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    // ── Helper ────────────────────────────────────────────────────────────
    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    // ── GET /file-upload ──────────────────────────────────────────────────
    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();
        model.addAttribute("progress", progress);
        return "pages/file-upload/file-upload";
    }

    // ── POST /file-upload/level1 ──────────────────────────────────────────
    // No validation — any file is accepted
    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam("file") MultipartFile file,
                                         Principal principal) {

        if (!challengeService.checkLevel1(file)) {
            return new ChallengeResponse(false,
                    "Not quite. Think about what file types can execute in a browser when served back.");
        }

        ChallengeProgress progress = getProgress(principal);
        if (!progress.isFileUploadLevel1Completed()) {
            progress.setFileUploadLevel1Completed(true);
            progress.addXp(100);
        }
        progressRepo.save(progress);
        // Save the file and build the URL the student can visit to trigger execution
// This URL is served by the /uploads/{filename} endpoint above
        try {
//            String savedName = challengeService.saveFile(file);
            String savedName = challengeService.saveFile(file, uploadDir);
            String fileUrl = "/file-upload/uploads/" + savedName;
            return new ChallengeResponse(true,
                    "Success! File accepted with no validation. +100 XP | " +
                            "Now visit this URL to trigger execution: <a href='" + fileUrl +
                            "' target='_blank'>" + fileUrl + "</a>");
        } catch (IOException e) {
            return new ChallengeResponse(true,
                    "File validated successfully. +100 XP (could not save for serving — check upload dir config)");
        }
    }

    // ── POST /file-upload/level2 ──────────────────────────────────────────
    // MIME-type check only — bypassed by disguising HTML as an image
    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam("file") MultipartFile file,
                                         Principal principal) {

        if (!challengeService.checkLevel2(file)) {
            return new ChallengeResponse(false,
                    "Not quite. Think about what the server is actually trusting to determine the file type.");
        }

        ChallengeProgress progress = getProgress(principal);
        if (!progress.isFileUploadLevel2Completed()) {
            progress.setFileUploadLevel2Completed(true);
            progress.addXp(200);
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true,
                "Nice! You bypassed the MIME-type check by disguising your payload as an image. +200 XP");
    }

    // ── POST /file-upload/level3 ──────────────────────────────────────────
    // Extension blacklist — bypassed with a double extension
    @PostMapping("/level3")
    @ResponseBody
    public ChallengeResponse checkLevel3(@RequestParam("file") MultipartFile file,
                                         Principal principal) {

        if (!challengeService.checkLevel3(file)) {
            return new ChallengeResponse(false,
                    "Not quite. Think about how the blacklist checks the filename and whether there's a gap in that logic.");
        }

        ChallengeProgress progress = getProgress(principal);
        if (!progress.isFileUploadLevel3Completed()) {
            progress.setFileUploadLevel3Completed(true);
            progress.addXp(300);

            if (progress.isFileUploadLevel1Completed() && progress.isFileUploadLevel2Completed()) {
                progress.setFileUploadBadgeEarned(true);
            }
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true,
                "You bypassed the blacklist with a double extension! +300 XP"
                        + (progress.isFileUploadBadgeEarned() ? " 🏆 Upload Exploiter badge earned!" : ""));
    }


    // ── GET /uploads/{filename} ───────────────────────────────────────────
// Serves uploaded files back to the browser with no safety headers.
//
// DELIBERATELY INSECURE — this is what makes the XSS fire:
//   - No Content-Disposition: attachment  (would force download instead of render)
//   - No Content-Security-Policy          (would block inline scripts)
//   - Content-Type is derived from the file extension, so .html = text/html
//     and the browser renders + executes it as a full web page.
//
// A real secure implementation would ALWAYS add:
//   Content-Disposition: attachment; filename="file.html"
// which tells the browser to download it rather than render it.
    @GetMapping("/uploads/{filename:.+}")
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
        try {
            Path filePath = Paths.get(uploadDir).resolve(filename).normalize();
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists()) {
                return ResponseEntity.notFound().build();
            }

            // Detect content type from file extension
            // .html → text/html → browser RENDERS it → script executes
            // A safe server would hardcode "application/octet-stream" here
            String contentType = filename.toLowerCase().endsWith(".html") || filename.toLowerCase().endsWith(".htm")
                    ? "text/html"
                    : "application/octet-stream";

            // NOTE: intentionally NOT setting Content-Disposition: attachment
            // That one header would prevent execution entirely — shown in the Learn tab
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}