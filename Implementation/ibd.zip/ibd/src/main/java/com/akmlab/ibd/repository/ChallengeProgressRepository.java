package com.akmlab.ibd.repository;

import com.akmlab.ibd.model.ChallengeProgress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ChallengeProgressRepository extends JpaRepository<ChallengeProgress, Long> {

    // Find progress for a specific logged-in user
    Optional<ChallengeProgress> findByUsername(String username);
}