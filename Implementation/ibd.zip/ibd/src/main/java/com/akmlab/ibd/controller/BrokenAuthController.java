package com.akmlab.ibd.controller;

import com.akmlab.ibd.dto.ChallengeResponse;
import com.akmlab.ibd.model.ChallengeProgress;
import com.akmlab.ibd.repository.ChallengeProgressRepository;
import com.akmlab.ibd.service.BrokenAuthChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
@RequestMapping("/broken-auth")
public class BrokenAuthController {

    private final BrokenAuthChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public BrokenAuthController(BrokenAuthChallengeService challengeService,
                                ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    private ChallengeProgress getProgress(Principal principal) {
        String username = principal.getName();
        return progressRepo.findByUsername(username)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress(username)));
    }

    @GetMapping
    public String showPage(Model model, Principal principal) {
        ChallengeProgress progress = (principal != null)
                ? getProgress(principal)
                : new ChallengeProgress();
        model.addAttribute("progress", progress);
        return "pages/broken-auth/broken-auth";
    }

    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam String username,
                                         @RequestParam String password,
                                         Principal principal) {
        if (!challengeService.checkLevel1(username, password)) {
            return new ChallengeResponse(false, "Incorrect credentials. Think about what an application ships with by default.");
        }
        ChallengeProgress progress = getProgress(principal);
        if (!progress.isBrokenAuthLevel1Completed()) {
            progress.setBrokenAuthLevel1Completed(true);
            progress.addXp(100);
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true, "Correct! Default credentials accepted. +100 XP");
    }

    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam String token,
                                         Principal principal) {
        if (!challengeService.checkLevel2(token)) {
            return new ChallengeResponse(false, "Token not accepted. Think about how this application generates session tokens.");
        }
        ChallengeProgress progress = getProgress(principal);
        if (!progress.isBrokenAuthLevel2Completed()) {
            progress.setBrokenAuthLevel2Completed(true);
            progress.addXp(200);
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true, "Nice! You identified a predictable session token. +200 XP");
    }

    @PostMapping("/level3")
    @ResponseBody
    public ChallengeResponse checkLevel3(@RequestParam String email,
                                         @RequestParam String password,
                                         Principal principal) {
        if (!challengeService.checkLevel3(email, password)) {
            return new ChallengeResponse(false, "No match found. Try a different email and password combination from the breach list.");
        }
        ChallengeProgress progress = getProgress(principal);
        if (!progress.isBrokenAuthLevel3Completed()) {
            progress.setBrokenAuthLevel3Completed(true);
            progress.addXp(300);

            if (progress.isBrokenAuthLevel1Completed() && progress.isBrokenAuthLevel2Completed()) {
                progress.setBrokenAuthBadgeEarned(true);
            }
        }
        progressRepo.save(progress);
        return new ChallengeResponse(true, "You simulated a credential stuffing attack! +300 XP"
                + (progress.isBrokenAuthBadgeEarned() ? " 🏆 Auth Cracker badge earned!" : ""));
    }
}