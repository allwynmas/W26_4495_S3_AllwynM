-- ── SQLi Challenge: Users table (Level 1) ────────────────────────────────
-- Simulates a vulnerable login query:
--   SELECT * FROM sqli_users WHERE username = 'USER_INPUT'
CREATE TABLE IF NOT EXISTS sqli_users (
                                          id       INT AUTO_INCREMENT PRIMARY KEY,
                                          username VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL,
    role     VARCHAR(50)  NOT NULL DEFAULT 'user'
    );

MERGE INTO sqli_users (id, username, password, role) KEY(id) VALUES
    (1, 'admin',   'supersecret123', 'admin'),
    (2, 'alice',   'password1',      'user'),
    (3, 'bob',     'password2',      'user'),
    (4, 'charlie', 'password3',      'user');

-- ── SQLi Challenge: Products table (Level 2) ─────────────────────────────
-- Simulates a vulnerable product lookup:
--   SELECT * FROM sqli_products WHERE id = USER_INPUT
CREATE TABLE IF NOT EXISTS sqli_products (
                                             id          INT AUTO_INCREMENT PRIMARY KEY,
                                             name        VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    price       DECIMAL(10,2),
    visible     BOOLEAN DEFAULT TRUE
    );

MERGE INTO sqli_products (id, name, description, price, visible) KEY(id) VALUES
    (1, 'Basic Widget',    'A standard widget',           9.99,  TRUE),
    (2, 'Pro Widget',      'An upgraded widget',          29.99, TRUE),
    (3, 'Secret Product',  'Not meant to be visible',     0.00,  FALSE),
    (4, 'Premium Widget',  'Top of the line widget',      99.99, TRUE);