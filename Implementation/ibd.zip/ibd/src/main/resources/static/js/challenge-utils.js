/**
 * challenge-utils.js
 * Shared utilities for all IBD challenge pages.
 */

/**
 * Attempts to unlock the next challenge level accordion.
 * Requires the previous level to have a .feedback-success element
 * before allowing the unlock — prevents skipping levels.
 *
 * @param {number} level  - The level number to unlock (e.g. 2 or 3)
 * @param {string} prefix - Optional ID prefix (default: "level", XSS page uses "xssLevel")
 */
function unlockLevel(level, prefix = "level") {
    // Check server-side completion state first (handles page refreshes)
    const alreadyDone = (typeof levelCompleted !== 'undefined') && levelCompleted[level - 1];
    // Also check if the user just solved it this session (feedback in DOM)
    const prevFeedback = document.getElementById(prefix + (level - 1) + "Feedback");
    const solvedThisSession = prevFeedback && prevFeedback.querySelector('.feedback-success');

    if (!alreadyDone && !solvedThisSession) {
        if (prevFeedback) {
            prevFeedback.innerHTML = `<div class="feedback-warning">⚠️ Complete Level ${level - 1} first before unlocking Level ${level}.</div>`;
        }
        const btn = document.getElementById("unlock" + capitalize(prefix) + level);
        if (btn) {
            btn.classList.add("shake");
            setTimeout(() => btn.classList.remove("shake"), 500);
        }
        return;
    }

    const collapse = document.getElementById(prefix + level);
    const button = collapse.previousElementSibling.querySelector("button");
    button.classList.remove("disabled");
    collapse.classList.add("show");
    collapse.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}