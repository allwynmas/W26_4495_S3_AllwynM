package com.akmlab.firstdemo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    @GetMapping("/")
    public String home() {
        return "pages/home";
    }

    @GetMapping("/how-to-use")
    public String howToUse() {
        return "pages/howto";
    }

    @GetMapping("/owasp")
    public String owasp() {
        return "pages/owasp";
    }

    @GetMapping("/sql-injection")
    public String sqlInjection() {
        return "pages/sql-injection";
    }

    @GetMapping("/xss")
    public String xss() {
        return "pages/xss";
    }

    @GetMapping("/broken-auth")
    public String brokenAuth() {
        return "pages/broken-auth";
    }

    @GetMapping("/security-misconfig")
    public String securityMisconfig() {
        return "pages/security-misconfig";
    }
}
