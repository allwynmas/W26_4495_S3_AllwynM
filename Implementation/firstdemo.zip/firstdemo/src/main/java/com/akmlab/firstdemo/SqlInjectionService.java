package com.akmlab.firstdemo;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SqlInjectionService {

    private final JdbcTemplate jdbc;

    public SqlInjectionService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // VULNERABLE: string concatenation
    public List<DemoUser> vulnerableFindByUsername(String input) {
        String sql =
                "SELECT id, username, password FROM demo_users " +
                        "WHERE username LIKE '%" + input + "%'";

        return jdbc.query(sql, (rs, rowNum) ->
                new DemoUser(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password")
                )
        );
    }

    // SAFE: parameterized query
    public List<DemoUser> safeFindByUsername(String input) {
        String sql =
                "SELECT id, username, password FROM demo_users " +
                        "WHERE username LIKE ?";

        return jdbc.query(sql, ps -> ps.setString(1, "%" + input + "%"),
                (rs, rowNum) -> new DemoUser(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("password")
                )
        );
    }
}
