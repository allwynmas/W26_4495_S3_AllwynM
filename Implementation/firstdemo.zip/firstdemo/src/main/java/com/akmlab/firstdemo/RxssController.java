package com.akmlab.firstdemo;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RxssController {

    // Report-Only so XSS payload still executes
    @ModelAttribute
    public void addSecurityHeaders(HttpServletResponse response) {
        response.setHeader("Content-Security-Policy-Report-Only", "default-src 'self'");
        // BLOCK XSS (hard mode)
        // response.setHeader("Content-Security-Policy", "default-src 'self'");
    }

    @GetMapping("/rxss")
    public String xssPage(@RequestParam(required = false) String input, Model model) {

        // Raw input for th:utext and th:text
        model.addAttribute("input", input);

        // Sanitized version
        if (input != null && !input.isBlank()) {
            String sanitized = input
                    .replace("<", "&lt;")
                    .replace(">", "&gt;");
            model.addAttribute("safeInput", sanitized);
        }

        return "pages/rxss";
    }
}