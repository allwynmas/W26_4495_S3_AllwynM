package com.akmlab.firstdemo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class SqlInjectionController {

    private final SqlInjectionService service;

    public SqlInjectionController(SqlInjectionService service) {
        this.service = service;
    }

    @GetMapping("/sql-injection")
    public String page(
            @RequestParam(value = "q", required = false) String q,
            @RequestParam(value = "mode", defaultValue = "vuln") String mode,
            Model model
    ) {
        // If user clicked "Clear Input" → no q parameter at all
        if (q == null) {
            model.addAttribute("q", "");
            model.addAttribute("mode", "safe");
            model.addAttribute("isVulnerable", false);
            model.addAttribute("results", List.of());
            return "pages/sql-injection";
        }

        String query = q.trim();
        boolean isVulnerable = mode.equalsIgnoreCase("vuln");

        // If q is empty → no results
        if (query.isBlank()) {
            model.addAttribute("q", "");
            model.addAttribute("mode", mode);
            model.addAttribute("isVulnerable", isVulnerable);
            model.addAttribute("results", List.of());
            return "pages/sql-injection";
        }

        List<DemoUser> results = List.of();

        try {
            results = isVulnerable
                    ? service.vulnerableFindByUsername(query)
                    : service.safeFindByUsername(query);

        } catch (Exception e) {
            // Error message for malformed SQL
            model.addAttribute("error", "Invalid SQL syntax or injection attempt.");
        }

        model.addAttribute("q", query);
        model.addAttribute("mode", mode);
        model.addAttribute("isVulnerable", isVulnerable);
        model.addAttribute("results", results);

        return "pages/sql-injection";
    }

}
