package com.akmlab.firstdemo;

public record DemoUser(int id, String username, String password) {}

