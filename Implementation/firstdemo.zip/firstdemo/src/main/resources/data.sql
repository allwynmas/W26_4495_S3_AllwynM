INSERT INTO demo_users (username, password) VALUES
                                                ('alice', 'alice123'),
                                                ('bob', 'bob123'),
                                                ('admin', 'adminPassword!');
