function scrollOnSearch({ queryParam = "q", searchSectionId, resultsSectionId }) {
    const params = new URLSearchParams(window.location.search);
    const queryValue = params.get(queryParam);

    const searchSection = document.getElementById(searchSectionId);
    const resultsSection = document.getElementById(resultsSectionId);

    // CASE 1: Initial load → no scroll
    if (!params.has(queryParam)) {
        return;
    }

    // CASE 2: User clicked Run with empty input → scroll to search form
    if (!queryValue || queryValue.trim() === "") {
        if (searchSection) {
            searchSection.scrollIntoView({ behavior: "smooth" });
        }
        return;
    }

    // CASE 3: User submitted a real query → scroll to results
    if (resultsSection) {
        resultsSection.scrollIntoView({ behavior: "smooth" });
    }
}