package com.akmlab.firstdemo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "challenge_progress")
public class ChallengeProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private boolean sqliLevel1Completed = false;
    private boolean sqliLevel2Completed = false;
    private boolean sqliLevel3Completed = false;

    public Long getId() {
        return id;
    }

    public boolean isSqliLevel1Completed() {
        return sqliLevel1Completed;
    }

    public void setSqliLevel1Completed(boolean sqliLevel1Completed) {
        this.sqliLevel1Completed = sqliLevel1Completed;
    }

    public boolean isSqliLevel2Completed() {
        return sqliLevel2Completed;
    }

    public void setSqliLevel2Completed(boolean sqliLevel2Completed) {
        this.sqliLevel2Completed = sqliLevel2Completed;
    }

    public boolean isSqliLevel3Completed() {
        return sqliLevel3Completed;
    }

    public void setSqliLevel3Completed(boolean sqliLevel3Completed) {
        this.sqliLevel3Completed = sqliLevel3Completed;
    }
}