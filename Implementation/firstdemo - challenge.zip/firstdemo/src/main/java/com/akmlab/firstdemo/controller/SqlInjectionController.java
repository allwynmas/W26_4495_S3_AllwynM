package com.akmlab.firstdemo.controller;

import com.akmlab.firstdemo.dto.ChallengeResponse;
import com.akmlab.firstdemo.model.ChallengeProgress;
import com.akmlab.firstdemo.repository.ChallengeProgressRepository;
import com.akmlab.firstdemo.service.SqlInjectionChallengeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/sql-injection")
public class SqlInjectionController {

    private final SqlInjectionChallengeService challengeService;
    private final ChallengeProgressRepository progressRepo;

    public SqlInjectionController(SqlInjectionChallengeService challengeService,
                                  ChallengeProgressRepository progressRepo) {
        this.challengeService = challengeService;
        this.progressRepo = progressRepo;
    }

    @GetMapping
    public String showPage(Model model) {
        ChallengeProgress progress = progressRepo.findById(1L)
                .orElseGet(() -> progressRepo.save(new ChallengeProgress()));

        model.addAttribute("progress", progress);
        return "pages/sql-injection/sqli";
    }

    @PostMapping("/level1")
    @ResponseBody
    public ChallengeResponse checkLevel1(@RequestParam String payload) {

        boolean success = challengeService.checkLevel1(payload);

        if (success) {
            ChallengeProgress progress = progressRepo.findById(1L).orElseThrow();
            progress.setSqliLevel1Completed(true);
            progressRepo.save(progress);
            return new ChallengeResponse(true, "Correct! You bypassed the WHERE clause.");
        }

        return new ChallengeResponse(false, "Try again. Hint: Use OR logic.");
    }

    @PostMapping("/level2")
    @ResponseBody
    public ChallengeResponse checkLevel2(@RequestParam String payload) {

        boolean success = challengeService.checkLevel2(payload);

        if (success) {
            ChallengeProgress progress = progressRepo.findById(1L).orElseThrow();
            progress.setSqliLevel2Completed(true);
            progressRepo.save(progress);
            return new ChallengeResponse(true, "Nice! You manipulated the numeric ID.");
        }

        return new ChallengeResponse(false, "Incorrect. Try manipulating numeric fields.");
    }

    @PostMapping("/level3")
    @ResponseBody
    public ChallengeResponse checkLevel3(@RequestParam String payload) {

        boolean success = challengeService.checkLevel3(payload);

        if (success) {
            ChallengeProgress progress = progressRepo.findById(1L).orElseThrow();
            progress.setSqliLevel3Completed(true);
            progressRepo.save(progress);
            return new ChallengeResponse(true, "You successfully performed blind SQLi!");
        }

        return new ChallengeResponse(false, "Not quite. Try boolean-based payloads.");
    }
}