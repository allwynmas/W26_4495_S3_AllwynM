package com.akmlab.firstdemo.repository;

import com.akmlab.firstdemo.model.ChallengeProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChallengeProgressRepository extends JpaRepository<ChallengeProgress, Long> {
}