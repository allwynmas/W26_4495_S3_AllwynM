CREATE TABLE IF NOT EXISTS challenge_progress (
                                                  id INT AUTO_INCREMENT PRIMARY KEY,
                                                  sqli_level1_completed BOOLEAN DEFAULT FALSE,
                                                  sqli_level2_completed BOOLEAN DEFAULT FALSE,
                                                  sqli_level3_completed BOOLEAN DEFAULT FALSE
);