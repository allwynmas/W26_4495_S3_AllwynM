package com.akmlab.firstdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
